<?php
$connection = mysqli_connect('localhost','root','') or die (mysqli_error($connection));
mysqli_select_db($connection,'userreg') or die (mysqli_error($connection));
?>