<?php
  $visitor_email= $_POST['email'];

  $email_from = "subscription@maryann.com";
  $email_subject="Subscription"; 
  $email_body = "This is a subscription from : $visitor_email.\n ";

  $to="maryannteeacademy@yahoo.com";       

  $headers= "from: $email_from\r\n";
  $headers= "Reply-To: $visitor_email\r\n";     

  mail($to, $email_subject, $email_body, $headers);
  header("Location:index.php");
 ?>