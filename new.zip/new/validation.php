<?php
session_start();
include ('connect.php');
if (isset($_POST['login'])) {
$name = $_POST['username'];
$pass = $_POST['password'];

$s = "SELECT * FROM users WHERE name = '$name' && pass = '$pass'";
$result = mysqli_query($connection,$s);
$nums = mysqli_num_rows($result);
if ($nums > 0) {
while ($num = mysqli_fetch_assoc($result)) {
 $_SESSION['username'] = $num['name'];
 header('location:resources.php');
    
}
}
else {
	echo "INVALID USERNAME AND PASSWORD";
}
      
        }
    
?>
