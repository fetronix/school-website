<?php

session_start();
include ('connect.php');
if (isset($_POST['register'])) {
$name = $_POST['username'];
$email = $_POST['email'];
$pass = $_POST['password'];
$pass1 = $_POST['password_1'];
if ($pass == $pass1) {
	$s = " SELECT * FROM users WHERE email = '$email'";
	$result = mysqli_query($connection,$s);

$num = mysqli_num_rows($result);

if($num == 1){
    echo" User Already Exists";
}
else{
    $reg = " INSERT INTO users(name , email , pass) VALUES ('$name','$email','$pass')";
     mysqli_query($connection, $reg);
     header("location:login.php");
}
}
else {
	echo "The password do not match";
}
}
?>
